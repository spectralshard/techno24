# partners
OctoberCMS partner slider plugin

####Options

- Background color

#### Fields

- Logo
- Partner Name
- Link to website
- Active
