# Changes to be expected in v2.0

Future changes will be added to this file.

* Drop support for PHP 7.0, only supports PHP 7.1+.
* The default value of the Setting `auto_redirect_creation_enabled` will be changed from `true` to `false`. 
