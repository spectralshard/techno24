# simplecontact
Contact Us plugin for October CMS

# What it do
* Add contact us form to frontend
* Send notification to you on receiving message
* Send auto reply to user who submits the contact us form
* Save messages to database
* Reply the message
* print the message

